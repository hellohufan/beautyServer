from rest_framework import serializers
from ic_shop import models as model


class ProfileTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = model.ProfileType
        fields = '__all__'


class ProfileSerializer(serializers.ModelSerializer):
    username = serializers.CharField(help_text='username', default='')
    password = serializers.CharField(help_text='password', write_only=True, default='')
    sex = serializers.CharField(help_text='sex', allow_null=True, allow_blank=True, required=False)
    dob = serializers.CharField(help_text='date of birth', allow_null=True, allow_blank=True, required=False)

    class Meta:
        model = model.Profile
        fields = '__all__'

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        instance = self.Meta.model(**validated_data)
        if password is not None:
            instance.set_password(password)
        instance.save()
        return instance

    def update(self, instance, validated_data):
        for attr, value in validated_data.items():
            if attr == 'password':
                instance.set_password(value)
            else:
                setattr(instance, attr, value)
        instance.save()
        return instance


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = model.Tag
        fields = '__all__'


class DeviceTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = model.DeviceType
        fields = '__all__'


class DeviceSerializer(serializers.ModelSerializer):
    name = serializers.CharField(help_text='name', required=False)
    description = serializers.CharField(help_text='description', required=False)
    status = serializers.CharField(help_text='status', required=False)
    deviceType_id = serializers.CharField(help_text='deviceType_id', required=True)
    manufacturer_id = serializers.CharField(help_text='manufacturer_id', required=True)

    class Meta:
        model = model.Device
        fields = 'name', 'description', 'status', 'deviceSn', 'deviceType_id', 'manufacturer_id'


class DeviceAdsSerializer(serializers.ModelSerializer):
    device_id = serializers.CharField(help_text='device_id', required=True)

    class Meta:
        model = model.DeviceAds
        fields = 'img', 'device_id'


class ImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = model.ImageUploader
        fields = '__all__'


class BrandSerializer(serializers.ModelSerializer):
    class Meta:
        model = model.Brand
        fields = '__all__'


class ShopItemSerializer(serializers.ModelSerializer):
    device_id = serializers.CharField(help_text='device_id', required=True)
    brand_id = serializers.CharField(help_text='brand_id', required=True)

    class Meta:
        model = model.ShopItem
        fields = 'title', 'description', 'status', 'content', 'prize', 'device_id', 'brand_id', 'tags'


class ItemOrderSerializer(serializers.ModelSerializer):
    shopItem_id = serializers.CharField(help_text='shopItem_id', required=True)

    class Meta:
        model = model.ItemOrder
        fields = 'orderNum', 'description', 'totalCount', 'totalPrize', 'shopItem_id'


class CommentSerializer(serializers.ModelSerializer):
    user_id = serializers.CharField(help_text='user_id', required=True)
    shopItem_id = serializers.CharField(help_text='shopItem_id', required=True)

    class Meta:
        model = model.Comment
        fields = 'title', 'description', 'user_id', 'shopItem_id'








