# -*- coding: utf-8 -*-


# true:看到debug stack,  False:正式服务器, 只返回404
def debug_env():
    return True
