# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from DjangoUeditor.models import UEditorField
from django.utils.translation import gettext_lazy as _
from django.contrib import admin
from django.utils import timezone
from django.contrib.auth.models import AbstractUser
from django.core.validators import MaxValueValidator, MinValueValidator


# Create your models here.
class ProfileType(models.Model):
    class Meta:
        verbose_name = u'用户类型'
        verbose_name_plural = u'用户类型'

    name = models.CharField(u'用户类型', max_length=20, default="")
    description = models.CharField(u'描述', max_length=1024, default="")

    def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
        return self.name


# user model  -> inherit default model
class Profile(AbstractUser):
    class Meta:
        verbose_name = u'用户'
        verbose_name_plural = u'用户'

    sex = models.CharField(u'性别', max_length=50, default="", null=True)
    dob = models.CharField(u'出生日期', max_length=50, default="", null=True)
    userType = models.ForeignKey(ProfileType, on_delete=models.CASCADE, default="", null=True)

    def __str__(self):
            # 在Python3中使用 def __str__(self):
            return "(ID: " + str(self.id) + ") " + " " + self.username


# user
# class Publisher(models.Model):
#     name = models.CharField(max_length=20, default="")
#     profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
#
#     def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
#         return self.name


class DeviceType(models.Model):
    class Meta:
        verbose_name = u'设备类型'
        verbose_name_plural = u'设备类型'

    name = models.CharField(u'标题', max_length=1024, null=True, default='')
    description = models.TextField(u'描述', blank=True,  default='')
    pub_date = models.DateTimeField(u'发表时间', auto_now_add=True, editable=True)
    update_time = models.DateTimeField(u'更新时间', auto_now=True, null=True)

    def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
        return self.name


class Device(models.Model):
    class Meta:
        verbose_name = u'设备'
        verbose_name_plural = u'设备'

    name = models.CharField(u'型号名称', max_length=1024, null=True, default='')
    description = models.TextField(u'描述', blank=True, default='', max_length=1024)
    status = models.IntegerField(
        u'0- 未激活, 1 - 激活, 2- 过期',
        default=1,
        validators=[MaxValueValidator(2), MinValueValidator(0)]
    )

    deviceSn = models.CharField(
        _('deviceSn'),
        unique=True,
        max_length=255,
        help_text=_('设备sn'),
        error_messages={
            'unique': _("device sn already exists."),
        },
    )

    deviceType = models.ForeignKey(DeviceType, on_delete=models.CASCADE)
    manufacturer = models.ForeignKey(Profile, on_delete=models.CASCADE)

    entry_date = models.DateTimeField(u'入库时间', auto_now_add=True, editable=True)
    update_time = models.DateTimeField(u'更新时间', auto_now=True, null=True)

    def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
            return self.name


class DeviceAds(models.Model):
    class Meta:
        verbose_name = u'设备广告'
        verbose_name_plural = u'设备广告'

    img = models.FileField(upload_to='upload')
    # article = models.ForeignKey(Article, default="")
    upload_time = models.DateTimeField(u'上传时间', auto_now=True, null=True)
    device = models.ForeignKey(Device, on_delete=models.CASCADE)

    def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
        return self.img.url + " " + self.device.name + " " + self.device.deviceType.name + " "


class Tag(models.Model):
    class Meta:
        verbose_name = u'标签'
        verbose_name_plural = u'标签'

    title = models.CharField(
        _('标签名称'),
        unique=True,
        max_length=150,
        help_text=_('Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.'),
        error_messages={
            'unique': _("A title with that tag already exists."),
        },
    )
    description = models.TextField(u'描述', default="", blank=True)
    # article = models.ManyToManyField(Article)

    def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
        return self.title


class Brand(models.Model):
    class Meta:
        verbose_name = '商品品牌'
        verbose_name_plural = '商品品牌'

    title = models.CharField(u'标题', max_length=1024, null=True, default='')
    status = models.IntegerField(
        u'0- 未激活, 1 - 激活, 2- 过期',
        default=1,
        validators=[MaxValueValidator(2), MinValueValidator(0)]
    )
    description = models.TextField(u'描述', blank=True, max_length=1024)
    entry_date = models.DateTimeField(u'入库时间', auto_now_add=True, editable=True)
    update_time = models.DateTimeField(u'更新时间', auto_now=True, null=True)

    def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
            return self.title


class ShopItem(models.Model):
    class Meta:
        verbose_name = u'商品'
        verbose_name_plural = u'商品'

    title = models.CharField(u'标题', max_length=256, null=True, default='')
    description = models.CharField(u'描述', blank=True, max_length=1024)
    prize = models.CharField(u'价格', max_length=256)

    status = models.IntegerField(
        u'0- 未激活, 1 - 激活, 2- 过期',
        default=1,
        validators=[MaxValueValidator(2), MinValueValidator(0)]
    )

    pub_date = models.DateTimeField(u'发表时间', auto_now_add=True, editable=True)
    update_time = models.DateTimeField(u'更新时间', auto_now=True, null=True)

    device = models.ForeignKey(Device, on_delete=models.CASCADE)
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE)

    tags = models.ManyToManyField(Tag)

    # 仅修改 content 字段
    content = UEditorField('内容', height=300, width=1000,
                           default=u'', blank=True, imagePath="uploads/images/",
                           toolbars='besttome', filePath='uploads/files/')

    def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
        return str(self.id) + " " + self.title + " " + self.device.name + "-" + " " \
               + str(timezone.localtime(self.pub_date).strftime('%Y/%m/%d  %H:%M'))


class ItemOrder(models.Model):
    class Meta:
        verbose_name = u'商品订单'
        verbose_name_plural = u'商品订单'

    orderNum = models.CharField(u'订单号', max_length=255, null=True, default='', unique=True)
    description = models.CharField(u'描述', blank=True, max_length=1024)
    totalCount = models.IntegerField(u'数量')
    totalPrize = models.IntegerField(u'总价')

    shopItem = models.ForeignKey(ShopItem, on_delete=models.CASCADE)

    pub_date = models.DateTimeField(u'发表时间', auto_now_add=True, editable=True)
    update_time = models.DateTimeField(u'更新时间', auto_now=True, null=True)

    def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
        return str(self.id) + " " + self.orderNum


class Comment(models.Model):
    class Meta:
        verbose_name = u'商品评论'
        verbose_name_plural = u'商品评论'

    title = models.CharField(u'标题', max_length=1024, null=True, default='')
    description = models.CharField(u'描述', blank=True, max_length=1024)
    user = models.ForeignKey(Profile, on_delete=models.CASCADE)
    shopItem = models.ForeignKey(ShopItem, on_delete=models.CASCADE)

    pub_date = models.DateTimeField(u'发表时间', auto_now_add=True, editable=True)
    update_time = models.DateTimeField(u'更新时间', auto_now=True, null=True)

    def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
        return str(self.id) + " " + self.title


class ImageUploader(models.Model):
    class Meta:
        verbose_name = u'商品图片'
        verbose_name_plural = u'商品图片'

    img = models.FileField(upload_to='upload')
    # article = models.ForeignKey(Article, default="")
    upload_time = models.DateTimeField(u'上传时间', auto_now=True, null=True)
    shopItem = models.ForeignKey(ShopItem, on_delete=models.CASCADE)

    def __str__(self):  # 在Python3中用 __str__ 代替 __unicode__
        return self.img.url + " " + self.shopItem.title + " " + self.shopItem.device.name + " "


def admin_pages_size():
    return 10


# customise admin UI allows one to edit at parent model page
class DeviceInline(admin.TabularInline):
    model = Device


# class BookAdmin(admin.ModelAdmin):
#     inlines = (CategoryInline,)


# ==== end

class ShopItemInline(admin.TabularInline):
    model = ShopItem


class DeviceAdmin(admin.ModelAdmin):
    inlines = (ShopItemInline,)
    list_per_page = admin_pages_size()


# ==== end


class ImageInline(admin.TabularInline):
    model = ImageUploader

# ==== end


class CommentAdmin(admin.ModelAdmin):
    raw_id_fields = ("shopItem",)
    model = Comment
    list_per_page = admin_pages_size()


class CommentInline(admin.TabularInline):
    model = Comment


class ShopItemAdmin(admin.ModelAdmin):
    raw_id_fields = ("device",)
    inlines = (ImageInline, CommentInline)
    save_as = True
    list_per_page = admin_pages_size()
# ==== end



