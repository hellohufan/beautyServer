# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class TouchreaderConfig(AppConfig):
    name = '冰糕机系统'
