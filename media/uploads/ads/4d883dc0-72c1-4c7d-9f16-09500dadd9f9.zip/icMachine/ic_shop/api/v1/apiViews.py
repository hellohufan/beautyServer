# coding:utf-8
from django.http import HttpResponse
from django.shortcuts import render

from ic_shop import models as model

from rest_framework.permissions import IsAuthenticated

from rest_framework import viewsets

from mBusi import serializers as ic_serializer

from rest_framework.response import Response
from rest_framework import status

from rest_framework_jwt.authentication import JSONWebTokenAuthentication

from rest_framework_extensions.bulk_operations.mixins import ListDestroyModelMixin

import logging
logger = logging.getLogger("django")  # 为loggers中定义的名称


# disable auth token operation
def allow_auth():
    return False


def index(request):
    new_article = model.ShopItem.objects.filter(id=1)
    if not new_article:
        return render(request, 'home.html')

    # logger.info("some info...", new_article[0].title)

    return render(request, 'home.html', {'info_dict': new_article[0]})


def add(request, a, b):

    c = int(a) + int(b)
    return HttpResponse(str(c))


# auto create token when user is created
# @receiver(post_save, sender=settings.AUTH_USER_MODEL)
# def create_auth_token(sender, instance=None, created=False, **kwargs):
#     if created:
#         Token.objects.create(user=instance)


# API VIEW
class ProfileTypeViewSet(ListDestroyModelMixin, viewsets.ModelViewSet):
    """ 
       Profile Type Tag
    """
    if allow_auth():
        authentication_classes = (JSONWebTokenAuthentication, )
        permission_classes = (IsAuthenticated,)

    queryset = model.ProfileType.objects.all()
    # queryset.query.set_limits(0, 5)
    serializer_class = ic_serializer.ProfileTypeSerializer


# inherits abstractUser
class ProfileViewSet(viewsets.ModelViewSet):
        """ 
         User profile, include auth user Model
        """
        # if allow_auth():
        #     authentication_classes = (JSONWebTokenAuthentication,)
        #     permission_classes = (IsAuthenticated,)

        queryset = model.Profile.objects.all()
        serializer_class = ic_serializer.ProfileSerializer

        def get_queryset(self):
            logger.info('getting request data user %s ', self.kwargs)
            return super(ProfileViewSet, self).get_queryset().order_by('id')

        def create(self, request, *args, **kwargs):
            logger.info('getting request data create user %s', request.data.copy())

            try:
                username = request.data["username"]
            except KeyError:
                username = ""

            try:
                password = request.data["password"]
            except KeyError:
                password = ""

            if not request.data or username == "" or password == "":
                return Response('Username or password should not be empty', status=status.HTTP_400_BAD_REQUEST)

            if model.Profile.objects.filter(username=request.data["username"]):
                return Response('Username already exists', status=status.HTTP_400_BAD_REQUEST)

            return super(ProfileViewSet, self).create(request, *args, **kwargs)


class DeviceTypeViewSet(ListDestroyModelMixin, viewsets.ModelViewSet):
    """
        device type
    """
    if allow_auth():
        authentication_classes = (JSONWebTokenAuthentication,)
        permission_classes = (IsAuthenticated,)

    queryset = model.DeviceType.objects.all()
    serializer_class = ic_serializer.DeviceTypeSerializer

    def get_queryset(self):
        logger.info('getting request data device type %s ', self.kwargs)
        # book_id = self.kwargs.get('book_pk', None)
        # if book_id:
        #     return Category.objects.filter(book=book_id).order_by('id')
        return super(DeviceTypeViewSet, self).get_queryset().order_by('id')

    def create(self, request, *args, **kwargs):
        device_type_data = request.data.copy()

        # /book/1/chapter/
        # if self.kwargs.get('book_pk', None):
        #     chapter_data['book_id'] = self.kwargs.get('book_pk', None)
        #     if not Book.objects.filter(id=se.get('book_pk', None)):
        #         return Response('book.py not found', status=status.HTTP_404_NOT_FOUND)lf.kwargs

        logger.info('getting request data create category %s', device_type_data)
        serializer = ic_serializer.DeviceTypeSerializer(data=device_type_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        error_msg = {
            'error_code': status.HTTP_400_BAD_REQUEST,
            'error_message': serializer.errors
        }

        return Response(error_msg, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        """ 
            e.g. 
            {\n
                delete bulk of child resources, add header: X-BULK-OPERATION : true \n
                # Request \n
                DELETE ../deviceType/1/device/ HTTP/1.1 \n
                Accept: application/json  \n
                X-BULK-OPERATION: true \n
            }
        """
        return super(DeviceTypeViewSet, self).destroy(request, *args, **kwargs)


class DeviceViewSet(ListDestroyModelMixin, viewsets.ModelViewSet):
    """
        Device
    """
    if allow_auth():
        authentication_classes = (JSONWebTokenAuthentication,)
        permission_classes = (IsAuthenticated,)

    queryset = model.Device.objects.all()
    serializer_class = ic_serializer.DeviceSerializer

    def get_queryset(self):
        logger.info('getting request data device  %s ', self.kwargs)
        # book_id = self.kwargs.get('book_pk', None)
        # if book_id:
        #     return Category.objects.filter(book=book_id).order_by('id')
        return super(DeviceViewSet, self).get_queryset().order_by('id')

    def create(self, request, *args, **kwargs):
        device_data = request.data.copy()

        # /book/1/chapter/
        # if self.kwargs.get('book_pk', None):
        #     chapter_data['book_id'] = self.kwargs.get('book_pk', None)
        #     if not Book.objects.filter(id=se.get('book_pk', None)):
        #         return Response('book.py not found', status=status.HTTP_404_NOT_FOUND)lf.kwargs

        logger.info('getting request data create category %s', device_data)
        serializer = ic_serializer.DeviceSerializer(data=device_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        error_msg = {
            'error_code': status.HTTP_400_BAD_REQUEST,
            'error_message': serializer.errors
        }

        return Response(error_msg, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        """ 
            e.g. 
            {\n
                delete bulk of child resources, add header: X-BULK-OPERATION : true \n
                # Request \n
                DELETE ../device/1/shopItem/ HTTP/1.1 \n
                Accept: application/json  \n
                X-BULK-OPERATION: true \n
            }
        """
        return super(DeviceViewSet, self).destroy(request, *args, **kwargs)


class DeviceAdsViewSet(ListDestroyModelMixin, viewsets.ModelViewSet):
    """
        device ads
    """
    if allow_auth():
        authentication_classes = (JSONWebTokenAuthentication,)
        permission_classes = (IsAuthenticated,)

    queryset = model.DeviceAds.objects.all()
    serializer_class = ic_serializer.DeviceAdsSerializer

    def get_queryset(self):
        logger.info('getting request data device ads %s ', self.kwargs)
        # book_id = self.kwargs.get('book_pk', None)
        # if book_id:
        #     return Category.objects.filter(book=book_id).order_by('id')
        return super(DeviceAdsViewSet, self).get_queryset().order_by('id')

    def create(self, request, *args, **kwargs):
        device_ads_data = request.data.copy()

        # /book/1/chapter/
        # if self.kwargs.get('book_pk', None):
        #     chapter_data['book_id'] = self.kwargs.get('book_pk', None)
        #     if not Book.objects.filter(id=se.get('book_pk', None)):
        #         return Response('book.py not found', status=status.HTTP_404_NOT_FOUND)lf.kwargs

        logger.info('getting request data create device_ads_data %s', device_ads_data)
        serializer = ic_serializer.DeviceAdsSerializer(data=device_ads_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        error_msg = {
            'error_code': status.HTTP_400_BAD_REQUEST,
            'error_message': serializer.errors
        }

        return Response(error_msg, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        """ 
            e.g. 
            {\n
                delete bulk of child resources, add header: X-BULK-OPERATION : true \n
                # Request \n
                DELETE ../device/1/deviceAds/ HTTP/1.1 \n
                Accept: application/json  \n
                X-BULK-OPERATION: true \n
            }
        """
        return super(DeviceAdsViewSet, self).destroy(request, *args, **kwargs)


class BrandViewSet(ListDestroyModelMixin, viewsets.ModelViewSet):
    """
        shop brand
    """
    if allow_auth():
        authentication_classes = (JSONWebTokenAuthentication,)
        permission_classes = (IsAuthenticated,)

    queryset = model.Brand.objects.all()
    serializer_class = ic_serializer.BrandSerializer

    def get_queryset(self):
        logger.info('getting request data device ads %s ', self.kwargs)
        # book_id = self.kwargs.get('book_pk', None)
        # if book_id:
        #     return Category.objects.filter(book=book_id).order_by('id')
        return super(BrandViewSet, self).get_queryset().order_by('id')

    def create(self, request, *args, **kwargs):
        brand_data = request.data.copy()

        # /book/1/chapter/
        # if self.kwargs.get('book_pk', None):
        #     chapter_data['book_id'] = self.kwargs.get('book_pk', None)
        #     if not Book.objects.filter(id=se.get('book_pk', None)):
        #         return Response('book.py not found', status=status.HTTP_404_NOT_FOUND)lf.kwargs

        logger.info('getting request data create device_ads_data %s', brand_data)
        serializer = ic_serializer.BrandSerializer(data=brand_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        error_msg = {
            'error_code': status.HTTP_400_BAD_REQUEST,
            'error_message': serializer.errors
        }

        return Response(error_msg, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        return super(BrandViewSet, self).destroy(request, *args, **kwargs)


class ShopItemViewSet(ListDestroyModelMixin, viewsets.ModelViewSet):
    """ 
        article \n
    """
    if allow_auth():
        authentication_classes = (JSONWebTokenAuthentication,)
        permission_classes = (IsAuthenticated,)

    queryset = model.ShopItem.objects.all()
    serializer_class = ic_serializer.ShopItemSerializer

    # @detail_route(methods=['delete'])
    # def deletes(self, request, pk=None):
    #     # check for the method provided
    #     # do your logic and return a Response object
    #     logger.info('getting request data delete article %s', request.data)
    #     pass

    def get_queryset(self):
        logger.info('getting request data shopItem %s ', self.kwargs)

        # /tag/1/shopItem/
        tag_id = self.kwargs.get('tag_pk', None)
        if tag_id:
            return model.ShopItem.objects.filter(tags=tag_id)

        # /device/1/shopItem/
        device_id = self.kwargs.get('device_pk', None)
        if device_id:
            return model.ShopItem.objects.filter(device=device_id).order_by('id')

        return super(ShopItemViewSet, self).get_queryset().order_by('id')

    def create(self, request, *args, **kwargs):
        shop_item_data = request.data.copy()
        arr_image = request.FILES.getlist('images')

        # /device/1/shopItem/
        if self.kwargs.get('device_pk', None):
            shop_item_data['device_id'] = self.kwargs.get('device_pk', None)
            if not model.DeviceType.objects.filter(id=self.kwargs.get('device_pk', None)):
                return Response('device not found', status=status.HTTP_404_NOT_FOUND)

        logger.info('getting request data create shop item %s', shop_item_data)

        shop_item_id = -1  # 用于图片保存，关联article id
        serializer = ic_serializer.ShopItemSerializer(data=shop_item_data)
        if serializer.is_valid():
            serializer.save()
            shop_item_id = serializer.data['id']

        error_msg = {
            'error_code': status.HTTP_400_BAD_REQUEST,
            'error_message': serializer.errors
        }

        if shop_item_id == -1:
            return Response(error_msg, status=status.HTTP_201_CREATED)

        # 文章图片数量不为0， 进行保存
        if len(arr_image) != 0:
            image_data = {}
            for img in arr_image:
                image_data["img"] = img
                image_data["shopItem"] = shop_item_id
                image_serializer = ic_serializer.ImageSerializer(data=image_data)
                if image_serializer.is_valid():
                    image_serializer.save()

        msg = {
            'error_code': status.HTTP_201_CREATED,
            'shopItem_id': serializer.data["id"]
        }

        return Response(msg, status=status.HTTP_201_CREATED)

    def destroy(self, request, *args, **kwargs):
        """ 
            e.g. 
            {\n
                delete bulk of resources, add header: X-BULK-OPERATION : true \n
                # Request \n
                DELETE /device/1/shopItem/ HTTP/1.1 \n
                Accept: application/json  \n
                X-BULK-OPERATION: true \n
            }
        """
        return super(ShopItemViewSet, self).destroy(request, *args, **kwargs)


class ItemOrderViewSet(ListDestroyModelMixin, viewsets.ModelViewSet):
    """
        device ads
    """
    if allow_auth():
        authentication_classes = (JSONWebTokenAuthentication,)
        permission_classes = (IsAuthenticated,)

    queryset = model.ItemOrder.objects.all()
    serializer_class = ic_serializer.ItemOrderSerializer

    def get_queryset(self):
        logger.info('getting request data device ads %s ', self.kwargs)
        # book_id = self.kwargs.get('book_pk', None)
        # if book_id:
        #     return Category.objects.filter(book=book_id).order_by('id')
        return super(ItemOrderViewSet, self).get_queryset().order_by('id')

    def create(self, request, *args, **kwargs):
        shopItem_order_data = request.data.copy()

        # /book/1/chapter/
        # if self.kwargs.get('book_pk', None):
        #     chapter_data['book_id'] = self.kwargs.get('book_pk', None)
        #     if not Book.objects.filter(id=se.get('book_pk', None)):
        #         return Response('book.py not found', status=status.HTTP_404_NOT_FOUND)lf.kwargs

        logger.info('getting request data create device_ads_data %s', shopItem_order_data)
        serializer = ic_serializer.ItemOrderSerializer(data=shopItem_order_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        error_msg = {
            'error_code': status.HTTP_400_BAD_REQUEST,
            'error_message': serializer.errors
        }

        return Response(error_msg, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        """ 
            e.g. 
            {\n
                delete bulk of child resources, add header: X-BULK-OPERATION : true \n
                # Request \n
                DELETE ../device/1/deviceAds/ HTTP/1.1 \n
                Accept: application/json  \n
                X-BULK-OPERATION: true \n
            }
        """
        return super(ItemOrderViewSet, self).destroy(request, *args, **kwargs)


class CommentViewSet(ListDestroyModelMixin, viewsets.ModelViewSet):
    """
        comment
    """
    if allow_auth():
        authentication_classes = (JSONWebTokenAuthentication,)
        permission_classes = (IsAuthenticated,)

    queryset = model.Comment.objects.all()
    serializer_class = ic_serializer.CommentSerializer

    def get_queryset(self):
        logger.info('getting request data comment %s ', self.kwargs)

        # /shopItem/1/comment/
        shop_item_id = self.kwargs.get('shopItem_pk', None)
        if shop_item_id:
            return model.Comment.objects.filter(shopItem=shop_item_id)

        return super(CommentViewSet, self).get_queryset().order_by('id')

    def create(self, request, *args, **kwargs):
        item_data = request.data.copy()

        # shopItem/1/comment/
        if self.kwargs.get('shopItem_pk', None):
            item_data['shop_item_id'] = self.kwargs.get('shopItem_pk', None)
            if not model.ShopItem.objects.filter(id=self.kwargs.get('shopItem_pk', None)):
                return Response('shop item not found', status=status.HTTP_404_NOT_FOUND)

        logger.info('getting request data create comment %s', item_data)
        serializer = ic_serializer.CommentSerializer(data=item_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        error_msg = {
            'error_code': status.HTTP_400_BAD_REQUEST,
            'error_message': serializer.errors
        }

        return Response(error_msg, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        """ 
            e.g. 
            {\n
                delete bulk of resources, add header: X-BULK-OPERATION : true \n
                # Request \n
                DELETE ../article/1/comment/ HTTP/1.1 \n
                Accept: application/json  \n
                X-BULK-OPERATION: true \n
            }
        """
        return super(CommentViewSet, self).destroy(request, *args, **kwargs)


class TagViewSet(ListDestroyModelMixin, viewsets.ModelViewSet):
    """ 
       article tag
    """
    if allow_auth():
        authentication_classes = (JSONWebTokenAuthentication, )
        permission_classes = (IsAuthenticated,)

    queryset = model.Tag.objects.all()
    # queryset.query.set_limits(0, 5)
    serializer_class = ic_serializer.TagSerializer

    def get_queryset(self):
        logger.info('getting request data tag %s ', self.kwargs)
        article_id = self.kwargs.get('article_pk', None)
        if article_id:
            return model.Tag.objects.filter(article=article_id).order_by('id')
        return super(TagViewSet, self).get_queryset().order_by('id')

    def create(self, request, *args, **kwargs):
        # logger.info('getting request data tag %s', request.data["title"])
        serializer = ic_serializer.TagSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        error_msg = {
            'error_code': status.HTTP_400_BAD_REQUEST,
            'error_message': serializer.errors
        }

        return Response(error_msg, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        """ 
            e.g. 
            {\n
                delete bulk of resources, add header: X-BULK-OPERATION : true \n
                # Request \n
                DELETE ../tag/ HTTP/1.1 \n
                Accept: application/json  \n
                X-BULK-OPERATION: true \n
            }
        """
        return super(TagViewSet, self).destroy(request, *args, **kwargs)


# class AuthTokenView(ObtainAuthToken, GenericAPIView):
#     pass

