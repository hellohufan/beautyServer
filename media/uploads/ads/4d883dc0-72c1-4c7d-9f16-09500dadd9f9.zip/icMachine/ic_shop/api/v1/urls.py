from django.conf.urls import url, include
from rest_framework.documentation import include_docs_urls

from ic_shop.api.v1 import apiViews
from ic_shop.api.v1 import authentication as jwt_auth

from rest_framework_nested import routers
router = routers.DefaultRouter()


"""
brand router
"""
router.register(r'brand', apiViews.BrandViewSet)


"""
shopItem router
"""
router.register(r'shopItem', apiViews.ShopItemViewSet)
# /shopItem/1/tag/
shopItem_tag_router = routers.NestedSimpleRouter(router, r'shopItem', lookup='shopItem')
shopItem_tag_router.register(r'tag', apiViews.TagViewSet, base_name='tag')

# /shopItem/1/comment/
shopItem_comment_router = routers.NestedSimpleRouter(router, r'shopItem', lookup='shopItem')
shopItem_comment_router.register(r'comment', apiViews.CommentViewSet, base_name='comment')

# /shopItem/1/itemOrder/
shopItem_itemOrder_router = routers.NestedSimpleRouter(router, r'shopItem', lookup='shopItem')
shopItem_itemOrder_router.register(r'itemOrder', apiViews.ItemOrderViewSet, base_name='itemOrder')


"""
item order router
"""
router.register(r'itemOrder', apiViews.ItemOrderViewSet)


"""
tag router
"""
router.register(r'tag', apiViews.TagViewSet)
# /tag/1/shopItem/
tag_item_router = routers.NestedSimpleRouter(router, r'tag', lookup='tag')
tag_item_router.register(r'shopItem', apiViews.ShopItemViewSet, base_name='shopItem')


"""
user router
"""
router.register(r'userType', apiViews.ProfileTypeViewSet)
router.register(r'user', apiViews.ProfileViewSet)

"""
deviceType -> device router
"""
router.register(r'deviceType', apiViews.DeviceTypeViewSet)
deviceType_device_router = routers.NestedSimpleRouter(router, r'deviceType', lookup='deviceType')
deviceType_device_router.register(r'device', apiViews.DeviceViewSet, base_name='device')


"""
device -> shop item router
"""
router.register(r'device', apiViews.DeviceViewSet)
device_shopItem_router = routers.NestedSimpleRouter(router, r'device', lookup='device')
device_shopItem_router.register(r'shopItem', apiViews.ShopItemViewSet, base_name='shopItem')


"""
device ads router
"""
router.register(r'deviceAds', apiViews.DeviceAdsViewSet)


"""
comment router
"""
router.register(r'comment', apiViews.CommentViewSet)

urlpatterns = [
        url(r'^api/', include(router.urls)),
        url(r'^api/', include(tag_item_router.urls)),  # tag/1/article/
        url(r'^api/', include(deviceType_device_router.urls)),  # deviceType/1/device/
        url(r'^api/', include(device_shopItem_router.urls)),  # device/1/shopItem/
        url(r'^api/', include(shopItem_comment_router.urls)),  # shopItem/1/comment/
        url(r'^api/', include(shopItem_tag_router.urls)),  # shopItem/1/tag/
        url(r'^api/', include(shopItem_itemOrder_router.urls)),  # shopItem/1/itemOrder/

        url(r'^docs/', include_docs_urls(title='mBusi API', permission_classes=[])),

        url(r'^api/login/', jwt_auth.obtain_jwt_token),
        url(r'^api/refresh/', jwt_auth.refresh_jwt_token),
        url(r'^api/verify/', jwt_auth.verify_jwt_token),
    ]
