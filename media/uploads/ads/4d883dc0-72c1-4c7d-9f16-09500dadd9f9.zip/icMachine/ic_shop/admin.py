# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from ic_shop import models as model

from django.contrib.auth.admin import UserAdmin


# Register your models here.
admin.site.site_header = '冰糕机后台管理系统'
admin.site.site_title = '冰糕机系统'
# admin.site.site_index_title = '冰糕机系统'
# admin.site.name = '冰糕机系统'


class ProfileAdmin(UserAdmin):
    pass

admin.site.register(model.ProfileType)
admin.site.register(model.Profile, ProfileAdmin)
admin.site.register(model.Brand)
admin.site.register(model.ShopItem, model.ShopItemAdmin)
admin.site.register(model.ItemOrder)
admin.site.register(model.Tag)
admin.site.register(model.Comment, model.CommentAdmin)
admin.site.register(model.ImageUploader)
admin.site.register(model.DeviceType)
admin.site.register(model.Device, model.DeviceAdmin)
admin.site.register(model.DeviceAds)
